import boto3

s3 = boto3.client("s3")

DEST_BUCKET = "derrick-dp-bucket"       # hardcoded destination bucket
DEST_PREFIX = "1-landing-zone/"         # fixed prefix in destination bucket

def lambda_handler(event, context):
    copied_files = []

    for record in event["Records"]:
        src_bucket = record["s3"]["bucket"]["name"]
        src_key = record["s3"]["object"]["key"]

        # Skip empty folder markers
        if src_key.endswith("/"):
            continue

        # Construct new key with fixed prefix
        dst_key = f"{DEST_PREFIX}{src_key}"

        print(f"Copying {src_key} from {src_bucket} → {DEST_BUCKET}/{dst_key}")

        s3.copy_object(
            CopySource={"Bucket": src_bucket, "Key": src_key},
            Bucket=DEST_BUCKET,
            Key=dst_key
        )

        copied_files.append(dst_key)

    return {
        "statusCode": 200,
        "body": f"Copied {len(copied_files)} files to {DEST_BUCKET}/{DEST_PREFIX}"
    }
